package com.ufcg.psoft.mercadofacil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadoFacilApplicationTests {

	@Test
	void contextLoads() {
	}

}
