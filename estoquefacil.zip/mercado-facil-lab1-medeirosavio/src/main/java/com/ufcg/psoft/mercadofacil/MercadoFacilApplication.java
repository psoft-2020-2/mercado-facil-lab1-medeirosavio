package com.ufcg.psoft.mercadofacil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MercadoFacilApplication {

	public static void main(String[] args) {
		SpringApplication.run(MercadoFacilApplication.class, args);
	}

}
