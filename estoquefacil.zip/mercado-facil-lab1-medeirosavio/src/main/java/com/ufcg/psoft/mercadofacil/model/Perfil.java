package com.ufcg.psoft.mercadofacil.model;

public interface Perfil {

    public String getNormal();

    public String getEspecial();

    public String getPremium();

}
